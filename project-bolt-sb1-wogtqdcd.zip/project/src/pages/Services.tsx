import React from 'react';
import { MapPin, Battery, Wifi, Lock, UserCheck, Headphones } from 'lucide-react';

const Services = () => {
  return (
    <div className="flex-1">
      {/* Hero Section */}
      <section className="bg-blue-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-6">Our Services</h1>
          <p className="text-xl">Comprehensive tracking solutions for your peace of mind</p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ServiceCard
              icon={<MapPin className="h-8 w-8 text-blue-600" />}
              title="Real-Time Tracking"
              description="Track your belongings in real-time with precise location updates and history."
              price="Included in all plans"
            />
            <ServiceCard
              icon={<Battery className="h-8 w-8 text-blue-600" />}
              title="Long Battery Life"
              description="Devices optimized for extended battery life, lasting up to several months."
              price="Included in all plans"
            />
            <ServiceCard
              icon={<Wifi className="h-8 w-8 text-blue-600" />}
              title="Wide Coverage"
              description="Reliable tracking across vast areas with our advanced network."
              price="Premium feature"
            />
            <ServiceCard
              icon={<Lock className="h-8 w-8 text-blue-600" />}
              title="Secure Data"
              description="End-to-end encryption and secure data storage for your privacy."
              price="Included in all plans"
            />
            <ServiceCard
              icon={<UserCheck className="h-8 w-8 text-blue-600" />}
              title="Multi-User Access"
              description="Share device access with family members or trusted contacts."
              price="Premium feature"
            />
            <ServiceCard
              icon={<Headphones className="h-8 w-8 text-blue-600" />}
              title="24/7 Support"
              description="Round-the-clock customer support for all your needs."
              price="Premium feature"
            />
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      
    </div>
  );
};

const ServiceCard = ({ icon, title, description, price }) => (
  <div className="bg-white p-6 rounded-lg shadow-md">
    <div className="mb-4">{icon}</div>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-gray-600 mb-4">{description}</p>
    <p className="text-sm text-blue-600 font-medium">{price}</p>
  </div>
);

const PricingCard = ({ title, price, features, highlighted = false }) => (
  <div className={`bg-white rounded-lg shadow-md p-6 ${highlighted ? 'ring-2 ring-blue-600' : ''}`}>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-3xl font-bold mb-6">{price}<span className="text-sm text-gray-600">/month</span></p>
    <ul className="space-y-3 mb-6">
      {features.map((feature, index) => (
        <li key={index} className="flex items-center space-x-2">
          <svg className="h-5 w-5 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M5 13l4 4L19 7"></path>
          </svg>
          <span>{feature}</span>
        </li>
      ))}
    </ul>
    <button className={`w-full py-2 px-4 rounded-lg font-semibold ${
      highlighted
        ? 'bg-blue-600 text-white hover:bg-blue-700'
        : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
    }`}>
      Choose Plan
    </button>
  </div>
);

export default Services;